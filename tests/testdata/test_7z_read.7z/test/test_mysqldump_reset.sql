INSERT INTO `test_table` VALUES (1, "value1");
